/*
    * Ho Chi Minh City University of Technology
    * Faculty of Computer Science and Engineering
    * Initial code for Assignment 2b
    * Programming Fundamentals CO1011 - Spring 2019
    * Author: Tran Ngoc Bao Duy
    * Date: 16.4.2019
    * Implementation of the header musketeer.h. You will write/edit this file to complete this assignment.
*/
#include "musketeer.h"

void advanture(int R, int N, int ID, int M, int* E, int nEvents) {
    // TODO: Simulate the advanture of musketeer
    
}