#include <iostream>
#include <stdio.h>
#include <iomanip>

#include "core.h"

using namespace std;

void Process();

/** Student should not modify the content of this file since it will be overwritten when you submit the source code.
 * The implementation should be done in core.cpp, core.h
 * Student can use global variables in their implementation.
 */

int main(int narg, char** argv) {
    Initialization();
    Process();
    Finalization();
    return 0;
}